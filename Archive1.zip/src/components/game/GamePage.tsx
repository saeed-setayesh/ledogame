"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { getSocket } from "@/lib/socket/client";
import LudoBoard from "./LudoBoard";
import TurnNotificationBar from "./TurnNotificationBar";
import GameNotification from "./GameNotification";
import VideoCall from "../video/VideoCall";
import ScreenRecorder from "./ScreenRecorder";
import Dice from "./Dice";
import { LudoGameState } from "@/lib/game/ludo-engine";

interface GamePageProps {
  game: any;
  currentUserId: string;
}

export default function GamePage({ game, currentUserId }: GamePageProps) {
  const router = useRouter();
  const [gameState, setGameState] = useState<LudoGameState | null>(null);
  const [availableMoves, setAvailableMoves] = useState<number[]>([]);
  const [showNoMovesNotification, setShowNoMovesNotification] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);

  useEffect(() => {
    const socket = getSocket();

    socket.emit("game:join", { gameId: game.id, userId: currentUserId });

    socket.on(
      "game:state",
      ({ gameState: state }: { gameState: LudoGameState }) => {
        setGameState(state);
        // Don't request moves here - server will send them when needed
        const playerIndex = state.players.findIndex(
          (p) => p.userId === currentUserId
        );
        const isMyTurn =
          playerIndex !== -1 && state.currentTurn === playerIndex;

        if (!isMyTurn) {
          setAvailableMoves([]);
        }
      }
    );

    socket.on("game:dice-rolled", ({ state }: { state: LudoGameState }) => {
      setGameState(state);
      // Don't request moves - server will send them automatically
      const playerIndex = state.players.findIndex(
        (p) => p.userId === currentUserId
      );
      const isMyTurn = playerIndex !== -1 && state.currentTurn === playerIndex;

      if (!isMyTurn) {
        setAvailableMoves([]);
      }
    });

    socket.on("game:piece-moved", ({ state }: { state: LudoGameState }) => {
      setGameState(state);
      // Clear available moves after a piece is moved
      // If player rolled 6, they need to roll again before getting new moves
      setAvailableMoves([]);
    });

    socket.on("game:available-moves", ({ moves }: { moves: number[] }) => {
      // Only update if it's our turn
      if (gameState) {
        const playerIndex = gameState.players.findIndex(
          (p) => p.userId === currentUserId
        );
        const isMyTurn =
          playerIndex !== -1 && gameState.currentTurn === playerIndex;

        if (isMyTurn) {
          setAvailableMoves(moves);
          // Show notification if no moves available
          if (moves.length === 0 && gameState.diceValue !== null) {
            setShowNoMovesNotification(true);
          }
        } else {
          setAvailableMoves([]);
        }
      } else {
        // If gameState not loaded yet, set moves (will be validated when state loads)
        setAvailableMoves(moves);
      }
    });

    socket.on("game:error", ({ message }: { message: string }) => {
      console.error("[Client] Game error:", message);
      alert(message);
    });

    return () => {
      socket.emit("game:leave", { gameId: game.id, userId: currentUserId });
    };
  }, [game.id, currentUserId]);

  // Clear available moves when it's not our turn
  useEffect(() => {
    if (gameState) {
      const playerIndex = gameState.players.findIndex(
        (p) => p.userId === currentUserId
      );
      const isMyTurn =
        playerIndex !== -1 && gameState.currentTurn === playerIndex;
      if (!isMyTurn) {
        setAvailableMoves([]);
      }
    }
  }, [gameState, currentUserId]);

  const handleRollDice = () => {
    if (!gameState) {
      console.warn("[Client] Cannot roll dice - game state not loaded");
      return;
    }

    // Double-check it's our turn before rolling
    const playerIndex = gameState.players.findIndex(
      (p) => p.userId === currentUserId
    );
    const isMyTurn =
      playerIndex !== -1 && gameState.currentTurn === playerIndex;
    const currentPlayer = gameState.players[playerIndex];
    const currentTurnPlayer = gameState.players[gameState.currentTurn];

    if (!isMyTurn) {
      console.warn(
        `[Client] Cannot roll dice - not your turn. Current turn: ${currentTurnPlayer?.userId}, Your index: ${playerIndex}, Current turn index: ${gameState.currentTurn}`
      );
      alert(
        `Not your turn. It's ${
          currentTurnPlayer?.userId?.startsWith("AI_") ? "AI" : "another player"
        }'s turn.`
      );
      return;
    }

    // Check if already rolled
    if (currentPlayer?.hasRolled) {
      console.warn("[Client] Cannot roll dice - already rolled this turn");
      return;
    }

    console.log(
      "[Client] Rolling dice - gameId:",
      game.id,
      "userId:",
      currentUserId,
      "playerIndex:",
      playerIndex,
      "currentTurn:",
      gameState.currentTurn
    );
    const socket = getSocket();
    socket.emit("game:roll-dice", { gameId: game.id, userId: currentUserId });
  };

  const handleMovePiece = (pieceId: number) => {
    const socket = getSocket();
    socket.emit("game:move-piece", {
      gameId: game.id,
      userId: currentUserId,
      pieceId,
    });
  };

  const handleExitGame = () => {
    if (isLeaving) return;

    // Confirm exit if game is active
    if (gameState && gameState.gameStatus === "ACTIVE") {
      const confirmed = window.confirm(
        "Are you sure you want to leave the game? Your progress will be saved."
      );
      if (!confirmed) return;
    }

    setIsLeaving(true);
    const socket = getSocket();

    // Leave the game
    socket.emit("game:leave", { gameId: game.id, userId: currentUserId });

    // Navigate back to lobby
    router.push("/lobby");
  };

  if (!gameState) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="text-center">
          <div className="text-xl text-white mb-4">Loading game...</div>
          {game.status === "WAITING" && (
            <div className="text-sm text-white/70">
              Waiting for more players to join...
            </div>
          )}
        </div>
      </div>
    );
  }

  const playerIndex = gameState.players.findIndex(
    (p) => p.userId === currentUserId
  );
  const currentPlayer =
    playerIndex !== -1 ? gameState.players[playerIndex] : null;
  const isMyTurn = playerIndex !== -1 && gameState.currentTurn === playerIndex;
  const isPracticeMode =
    gameState.players.some((p) => p.userId.startsWith("AI_")) &&
    gameState.players.length === 2;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative flex flex-col pb-24 md:pb-28">
      {/* Exit Button - Top left */}
      <button
        onClick={handleExitGame}
        disabled={isLeaving}
        className="fixed top-4 left-4 z-50 w-12 h-12 md:w-14 md:h-14 rounded-xl bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-2 border-gray-300 dark:border-gray-600 flex items-center justify-center hover:scale-110 active:scale-95 transition-all duration-300 shadow-lg hover:bg-red-50 dark:hover:bg-red-900/20 group"
        title="Exit Game"
      >
        <svg
          className="w-6 h-6 md:w-7 md:h-7 text-gray-700 dark:text-gray-300 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M6 18L18 6M6 6l12 12"
          />
        </svg>
      </button>

      {/* Game Notification - Top of screen */}
      <GameNotification
        message="No moves available - Turn will skip"
        type="warning"
        duration={2500}
        show={showNoMovesNotification}
        onClose={() => setShowNoMovesNotification(false)}
      />

      {/* Game Board - Mobile-first responsive */}
      <div className="flex-1 flex items-center justify-center py-2 md:py-4 px-2 md:px-4">
        <LudoBoard
          gameState={gameState}
          currentUserId={currentUserId}
          onMovePiece={handleMovePiece}
          availableMoves={availableMoves}
        />
      </div>

      {/* Dice - Fixed position bottom-right on mobile, center-bottom on desktop */}
      <div className="fixed bottom-20 right-4 md:bottom-28 md:right-1/2 md:translate-x-1/2 z-30">
        <Dice
          value={gameState.diceValue}
          onRoll={
            isMyTurn && !currentPlayer?.hasRolled ? handleRollDice : undefined
          }
          disabled={!isMyTurn || currentPlayer?.hasRolled || false}
          rolling={false}
        />
      </div>

      {/* Turn Notification Bar - Fixed at bottom */}
      <TurnNotificationBar
        gameState={gameState}
        currentUserId={currentUserId}
        availableMoves={availableMoves}
        onRollDice={handleRollDice}
        isPracticeMode={isPracticeMode}
      />

      {/* Video/Audio and Recorder - Icon buttons side by side */}
      <div className="fixed top-4 right-4 z-30">
        <div className="flex items-center gap-2">
          <VideoCall
            gameId={game.id}
            userId={currentUserId}
            players={game.players.map((p: any) => ({
              id: p.id,
              userId: p.userId,
              username: p.user.username,
            }))}
          />
          <ScreenRecorder gameId={game.id} />
        </div>
      </div>
    </div>
  );
}
