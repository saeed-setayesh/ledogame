"use client";

import { useState } from "react";
import { formatUSDT } from "@/lib/utils";
import {
  Trophy,
  Target,
  TrendingUp,
  Flame,
  Wallet,
  Gamepad2,
  User,
  BarChart3,
  ArrowRightLeft,
} from "lucide-react";
import RecentGames from "./RecentGames";
import Achievements from "./Achievements";
import AvatarSelector from "./AvatarSelector";
import LeaderboardCard from "./LeaderboardCard";
import FriendRequests from "./FriendRequests";
import Link from "next/link";

interface User {
  id: string;
  username: string;
  email: string;
  level: number;
  xp: number;
  totalGames: number;
  totalWins: number;
  walletBalance: any;
  createdAt: Date;
  avatar?: string | null;
}

interface ProfileProps {
  user: User;
}

export default function ProfileComponent({ user }: ProfileProps) {
  const [activeTab, setActiveTab] = useState<
    "overview" | "games" | "friends" | "customize"
  >("overview");

  const xpForNextLevel = user.level * 1000;
  const xpProgress = (user.xp % 1000) / 1000;
  const winRate =
    user.totalGames > 0 ? (user.totalWins / user.totalGames) * 100 : 0;
  const totalEarnings = user.totalWins * 10; // Mock calculation
  const currentStreak = 3; // Mock data

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="max-w-6xl mx-auto space-y-4 md:space-y-6">
        {/* Profile Header */}
        <div className="bg-card border border-border rounded-xl p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-4 md:gap-6">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-4xl md:text-5xl flex-shrink-0">
              {user.avatar || "👤"}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-accent mb-2">
                {user.username}
              </h1>
              <div className="flex flex-wrap items-center gap-4 text-sm md:text-base">
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-primary" />
                  <span className="font-semibold">Level {user.level}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-success" />
                  <span>{user.totalWins} Wins</span>
                </div>
                <div className="flex items-center gap-2">
                  <Gamepad2 className="w-4 h-4 text-info" />
                  <span>{user.totalGames} Games</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-4 py-2 rounded-lg font-semibold whitespace-nowrap min-h-[44px] transition-colors ${
              activeTab === "overview"
                ? "bg-primary text-white"
                : "bg-card border border-border text-foreground/70"
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab("games")}
            className={`px-4 py-2 rounded-lg font-semibold whitespace-nowrap min-h-[44px] transition-colors ${
              activeTab === "games"
                ? "bg-primary text-white"
                : "bg-card border border-border text-foreground/70"
            }`}
          >
            Games
          </button>
          <button
            onClick={() => setActiveTab("friends")}
            className={`px-4 py-2 rounded-lg font-semibold whitespace-nowrap min-h-[44px] transition-colors ${
              activeTab === "friends"
                ? "bg-primary text-white"
                : "bg-card border border-border text-foreground/70"
            }`}
          >
            Friends
          </button>
          <button
            onClick={() => setActiveTab("customize")}
            className={`px-4 py-2 rounded-lg font-semibold whitespace-nowrap min-h-[44px] transition-colors ${
              activeTab === "customize"
                ? "bg-primary text-white"
                : "bg-card border border-border text-foreground/70"
            }`}
          >
            Customize
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === "overview" && (
          <div className="space-y-4 md:space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="w-5 h-5 text-success" />
                  <span className="text-sm text-foreground/70">Win Rate</span>
                </div>
                <div className="text-2xl font-bold">{winRate.toFixed(1)}%</div>
              </div>
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Flame className="w-5 h-5 text-danger" />
                  <span className="text-sm text-foreground/70">
                    Current Streak
                  </span>
                </div>
                <div className="text-2xl font-bold">{currentStreak}</div>
              </div>
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span className="text-sm text-foreground/70">
                    Total Earnings
                  </span>
                </div>
                <div className="text-2xl font-bold text-success">
                  {formatUSDT(totalEarnings)} USDT
                </div>
              </div>
              <div className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Wallet className="w-5 h-5 text-info" />
                  <span className="text-sm text-foreground/70">Balance</span>
                </div>
                <div className="text-2xl font-bold text-primary">
                  {formatUSDT(user.walletBalance.toString())} USDT
                </div>
              </div>
            </div>

            {/* XP Progress */}
            <div className="bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  <span className="font-semibold">Level Progress</span>
                </div>
                <span className="text-sm text-foreground/70">
                  {user.xp} / {xpForNextLevel} XP
                </span>
              </div>
              <div className="w-full bg-background rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-primary to-accent h-3 rounded-full transition-all"
                  style={{ width: `${xpProgress * 100}%` }}
                />
              </div>
            </div>

            {/* Achievements Preview */}
            <Achievements />

            {/* Leaderboard */}
            <LeaderboardCard currentUserId={user.id} />
          </div>
        )}

        {activeTab === "games" && (
          <div className="space-y-4 md:space-y-6">
            <RecentGames />
          </div>
        )}

        {activeTab === "friends" && (
          <div className="space-y-4 md:space-y-6">
            <FriendRequests />
          </div>
        )}

        {activeTab === "customize" && (
          <div className="space-y-4 md:space-y-6">
            <AvatarSelector
              currentAvatar={user.avatar}
              onAvatarChange={() => {
                // Refresh page or update state
                window.location.reload();
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}
