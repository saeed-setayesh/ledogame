import { getCurrentUser } from "@/lib/auth-helpers";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Link from "next/link";
import {
  Gamepad2,
  Coins,
  Trophy,
  Target,
  Play,
  Swords,
  Wallet,
  User,
  Settings,
  Users,
  UserPlus,
  Activity,
  Bell,
  BarChart3,
  TrendingUp,
  Info,
  HelpCircle,
  Crown,
  Flame,
  Dices,
  Shield,
} from "lucide-react";
import { formatUSDT } from "@/lib/utils";

export default async function HomePage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/auth/signin");
  }

  const dbUser = await prisma.user.findUnique({
    where: { id: user.id },
    select: {
      level: true,
      xp: true,
      totalGames: true,
      totalWins: true,
      walletBalance: true,
      isAdmin: true,
    },
  });

  const winRate =
    dbUser && dbUser.totalGames > 0
      ? (dbUser.totalWins / dbUser.totalGames) * 100
      : 0;

  const xpForNextLevel = (dbUser?.level || 1) * 1000;
  const xpProgress = dbUser ? (dbUser.xp % 1000) / 1000 : 0;

  // Get pending friend requests count
  const pendingRequests = await prisma.friend.count({
    where: {
      friendId: user.id,
      status: "PENDING",
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <div className="container mx-auto px-4 py-4 md:py-8 space-y-4 md:space-y-6">
        {/* Hero Section */}
        <div className="text-center mb-6 md:mb-8">
          <div className="flex items-center justify-center gap-3 md:gap-4 mb-4">
            <Dices className="w-8 h-8 md:w-12 md:h-12 text-primary animate-pulse" />
            <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-accent animate-pulse-glow">
              Ludo Game
            </h1>
            <Dices className="w-8 h-8 md:w-12 md:h-12 text-accent animate-pulse" />
          </div>
          <div className="flex items-center justify-center gap-2 mb-2">
            <p className="text-lg md:text-xl text-foreground/90 font-semibold">
              Welcome back,
            </p>
            <div className="px-3 py-1 bg-primary/20 border border-primary/30 rounded-full">
              <span className="text-primary font-bold">{user.username}</span>
            </div>
          </div>
          <div className="flex items-center justify-center gap-2 mb-4">
            <Crown className="w-5 h-5 text-accent" />
            <span className="text-sm md:text-base text-foreground/70">
              Level {dbUser?.level || 1}
            </span>
          </div>

          {/* Game Mode Selection with Radio Buttons */}
          <div className="flex items-center justify-center gap-4 md:gap-6 mt-4 md:mt-6">
            <label className="flex items-center gap-2 cursor-pointer group">
              <input
                type="radio"
                name="gameMode"
                value="solo"
                defaultChecked
                className="w-5 h-5 text-primary focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background cursor-pointer"
              />
              <div className="flex items-center gap-2">
                <User className="w-5 h-5 text-foreground/70 group-hover:text-primary transition-colors" />
                <span className="text-sm md:text-base font-medium text-foreground/70 group-hover:text-foreground transition-colors">
                  Solo
                </span>
              </div>
            </label>
            <label className="flex items-center gap-2 cursor-pointer group">
              <input
                type="radio"
                name="gameMode"
                value="team"
                className="w-5 h-5 text-primary focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background cursor-pointer"
              />
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-foreground/70 group-hover:text-primary transition-colors" />
                <span className="text-sm md:text-base font-medium text-foreground/70 group-hover:text-foreground transition-colors">
                  Team
                </span>
              </div>
            </label>
            <label className="flex items-center gap-2 cursor-pointer group">
              <input
                type="radio"
                name="gameMode"
                value="tournament"
                className="w-5 h-5 text-primary focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background cursor-pointer"
              />
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-foreground/70 group-hover:text-primary transition-colors" />
                <span className="text-sm md:text-base font-medium text-foreground/70 group-hover:text-foreground transition-colors">
                  Tournament
                </span>
              </div>
            </label>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          <div className="bg-card border border-border rounded-xl p-3 md:p-4 hover:border-primary transition-colors">
            <div className="flex items-center gap-2 mb-2">
              <Coins className="w-4 h-4 md:w-5 md:h-5 text-primary" />
              <span className="text-xs md:text-sm text-foreground/70">
                Balance
              </span>
            </div>
            <div className="text-lg md:text-2xl font-bold text-primary">
              {formatUSDT(dbUser?.walletBalance.toString() || "0")}
            </div>
            <div className="text-xs text-foreground/50">USDT</div>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 md:p-4 hover:border-primary transition-colors">
            <div className="flex items-center gap-2 mb-2">
              <Gamepad2 className="w-4 h-4 md:w-5 md:h-5 text-info" />
              <span className="text-xs md:text-sm text-foreground/70">
                Games
              </span>
            </div>
            <div className="text-lg md:text-2xl font-bold text-info">
              {dbUser?.totalGames || 0}
            </div>
            <div className="text-xs text-foreground/50">Played</div>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 md:p-4 hover:border-primary transition-colors">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-4 h-4 md:w-5 md:h-5 text-success" />
              <span className="text-xs md:text-sm text-foreground/70">
                Wins
              </span>
            </div>
            <div className="text-lg md:text-2xl font-bold text-success">
              {dbUser?.totalWins || 0}
            </div>
            <div className="text-xs text-foreground/50">
              {winRate.toFixed(1)}% win rate
            </div>
          </div>
          <div className="bg-card border border-border rounded-xl p-3 md:p-4 hover:border-primary transition-colors">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="w-4 h-4 md:w-5 md:h-5 text-danger" />
              <span className="text-xs md:text-sm text-foreground/70">
                Streak
              </span>
            </div>
            <div className="text-lg md:text-2xl font-bold text-danger">3</div>
            <div className="text-xs text-foreground/50">Current</div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 md:gap-4">
          <Link
            href="/lobby"
            className="bg-gradient-to-br from-primary/20 to-primary/10 border-2 border-primary/30 rounded-xl p-4 md:p-6 hover:border-primary hover:scale-105 transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-20 h-20 bg-primary/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
            <div className="relative">
              <div className="flex items-center justify-center w-12 h-12 md:w-16 md:h-16 bg-primary/20 rounded-full mb-3 group-hover:scale-110 transition-transform">
                <Play className="w-6 h-6 md:w-8 md:h-8 text-primary" />
              </div>
              <h3 className="font-bold text-sm md:text-base mb-1">Play Game</h3>
              <p className="text-xs text-foreground/70">Start playing</p>
            </div>
          </Link>

          <Link
            href="/wallet"
            className="bg-gradient-to-br from-info/20 to-info/10 border-2 border-info/30 rounded-xl p-4 md:p-6 hover:border-info hover:scale-105 transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-20 h-20 bg-info/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
            <div className="relative">
              <div className="flex items-center justify-center w-12 h-12 md:w-16 md:h-16 bg-info/20 rounded-full mb-3 group-hover:scale-110 transition-transform">
                <Wallet className="w-6 h-6 md:w-8 md:h-8 text-info" />
              </div>
              <h3 className="font-bold text-sm md:text-base mb-1">Wallet</h3>
              <p className="text-xs text-foreground/70">Manage USDT</p>
            </div>
          </Link>

          <Link
            href="/profile"
            className="bg-gradient-to-br from-accent/20 to-accent/10 border-2 border-accent/30 rounded-xl p-4 md:p-6 hover:border-accent hover:scale-105 transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-20 h-20 bg-accent/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
            <div className="relative">
              <div className="flex items-center justify-center w-12 h-12 md:w-16 md:h-16 bg-accent/20 rounded-full mb-3 group-hover:scale-110 transition-transform">
                <User className="w-6 h-6 md:w-8 md:h-8 text-accent" />
              </div>
              <h3 className="font-bold text-sm md:text-base mb-1">Profile</h3>
              <p className="text-xs text-foreground/70">View stats</p>
            </div>
          </Link>

          <Link
            href="/profile?tab=friends"
            className="bg-gradient-to-br from-success/20 to-success/10 border-2 border-success/30 rounded-xl p-4 md:p-6 hover:border-success hover:scale-105 transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-20 h-20 bg-success/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
            <div className="relative">
              <div className="flex items-center justify-center w-12 h-12 md:w-16 md:h-16 bg-success/20 rounded-full mb-3 group-hover:scale-110 transition-transform relative">
                <Users className="w-6 h-6 md:w-8 md:h-8 text-success" />
                {pendingRequests > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-danger rounded-full flex items-center justify-center text-xs font-bold text-white">
                    {pendingRequests}
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm md:text-base mb-1">Friends</h3>
              <p className="text-xs text-foreground/70">
                {pendingRequests > 0 ? `${pendingRequests} requests` : "Manage"}
              </p>
            </div>
          </Link>

          <div className="bg-gradient-to-br from-purple/20 to-purple/10 border-2 border-purple/30 rounded-xl p-4 md:p-6 group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-20 h-20 bg-purple/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
            <div className="relative">
              <div className="flex items-center justify-center w-12 h-12 md:w-16 md:h-16 bg-purple/20 rounded-full mb-3">
                <Trophy className="w-6 h-6 md:w-8 md:h-8 text-purple" />
              </div>
              <h3 className="font-bold text-sm md:text-base mb-1">
                Tournaments
              </h3>
              <p className="text-xs text-foreground/70">Coming soon</p>
            </div>
          </div>

          {/* Admin Panel Link (only for admins) */}
          {dbUser?.isAdmin && (
            <Link
              href="/admin"
              className="bg-gradient-to-br from-danger/20 to-danger/10 border-2 border-danger/30 rounded-xl p-4 md:p-6 hover:border-danger hover:scale-105 transition-all group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-20 h-20 bg-danger/10 rounded-full -mr-10 -mt-10 blur-xl"></div>
              <div className="relative">
                <div className="flex items-center justify-center w-12 h-12 md:w-16 md:h-16 bg-danger/20 rounded-full mb-3 group-hover:scale-110 transition-transform relative">
                  <Shield className="w-6 h-6 md:w-8 md:h-8 text-danger" />
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full border-2 border-card"></span>
                </div>
                <h3 className="font-bold text-sm md:text-base mb-1">Admin</h3>
                <p className="text-xs text-foreground/70">Dashboard</p>
              </div>
            </Link>
          )}
        </div>

        {/* Level Progress & Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          <div className="bg-card border border-border rounded-xl p-4 md:p-6">
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-primary" />
              <h3 className="text-lg font-semibold">Level Progress</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-foreground/70">XP</span>
                <span className="font-semibold">
                  {dbUser?.xp || 0} / {xpForNextLevel}
                </span>
              </div>
              <div className="w-full bg-background rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-primary to-accent h-3 rounded-full transition-all"
                  style={{ width: `${xpProgress * 100}%` }}
                />
              </div>
              <div className="flex items-center gap-4 text-sm text-foreground/70">
                <div className="flex items-center gap-1">
                  <BarChart3 className="w-4 h-4" />
                  <span>Win Rate: {winRate.toFixed(1)}%</span>
                </div>
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  <span>Level {dbUser?.level || 1}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-4 md:p-6">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="w-5 h-5 text-info" />
              <h3 className="text-lg font-semibold">Quick Stats</h3>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground/70">
                  Total Earnings
                </span>
                <span className="font-bold text-success">
                  {formatUSDT((dbUser?.totalWins || 0) * 10)} USDT
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground/70">Games Played</span>
                <span className="font-bold">{dbUser?.totalGames || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground/70">Victories</span>
                <span className="font-bold text-success">
                  {dbUser?.totalWins || 0}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* How to Play */}
        <div className="bg-card border border-border rounded-xl p-4 md:p-6">
          <div className="flex items-center gap-2 mb-4">
            <HelpCircle className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">How to Play</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-primary">1</span>
              </div>
              <div>
                <p className="font-semibold mb-1">Create or Join</p>
                <p className="text-foreground/70">
                  Start a new game or join an existing one from the lobby
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-primary">2</span>
              </div>
              <div>
                <p className="font-semibold mb-1">Play & Win</p>
                <p className="text-foreground/70">
                  Roll the dice, move your pieces, and be the first to finish
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-primary">3</span>
              </div>
              <div>
                <p className="font-semibold mb-1">Earn Rewards</p>
                <p className="text-foreground/70">
                  Win USDT prizes and climb the leaderboard
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
