import { getCurrentUser } from "@/lib/auth-helpers"
import { redirect } from "next/navigation"
import WalletDashboard from "@/components/wallet/WalletDashboard"

export default async function WalletPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/signin")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      <div className="max-w-2xl mx-auto">
        <WalletDashboard userId={user.id} />
      </div>
    </div>
  )
}

