/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    // Disable TypeScript type errors during build
    ignoreBuildErrors: true,
  },
};

module.exports = nextConfig;
