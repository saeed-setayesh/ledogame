"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";

interface PracticeModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

export default function PracticeModeModal({
  isOpen,
  onClose,
  userId,
}: PracticeModeModalProps) {
  const router = useRouter();
  const [aiPlayers, setAiPlayers] = useState(1);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleStartPractice = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/game/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          gameType: "SOLO",
          maxPlayers: 1 + aiPlayers,
          entryFee: 0,
          aiPlayers,
          practiceMode: true,
        }),
      });

      const data = await response.json();
      if (data.game) {
        router.push(`/game/${data.game.id}`);
      }
    } catch (error) {
      console.error("Failed to create practice game:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-card border border-border rounded-2xl shadow-2xl p-6 w-full max-w-md mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-accent">
            Practice Mode
          </h2>
          <button
            onClick={onClose}
            className="text-foreground/70 hover:text-foreground transition-colors"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        <div className="space-y-6">
          <div>
            <p className="text-sm text-foreground/70 mb-4">
              Play against AI opponents to practice and improve your skills. No
              entry fee required!
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-3">
              Number of AI Players: {aiPlayers}
            </label>
            <input
              type="range"
              min="1"
              max="3"
              value={aiPlayers}
              onChange={(e) => setAiPlayers(parseInt(e.target.value))}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-foreground/70 mt-1">
              <span>1 AI</span>
              <span>3 AI</span>
            </div>
            <p className="text-xs text-foreground/60 mt-2">
              You will play with {aiPlayers} AI player{aiPlayers > 1 ? "s" : ""}{" "}
              (Total: {1 + aiPlayers} players)
            </p>
          </div>

          <button
            onClick={handleStartPractice}
            disabled={loading}
            className="w-full py-4 bg-gradient-to-r from-primary to-secondary rounded-lg font-semibold text-white hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Starting..." : "Start Practice Game"}
          </button>
        </div>
      </div>
    </div>
  );
}
